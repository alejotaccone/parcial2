﻿using Biblioteca_de_Clases;
namespace Test_Exeption
{
    internal class Program
    {

        Estudiante e1 = new Estudiante(2018,null,"Perez", new List<string>() { "Programacion", "Matematicas", "Ingles" });

   

        Console.WriteLine();
        



    }
}
