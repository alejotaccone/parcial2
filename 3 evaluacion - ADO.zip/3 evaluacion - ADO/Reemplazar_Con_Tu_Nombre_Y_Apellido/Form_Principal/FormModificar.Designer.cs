﻿namespace Form_Animales
{
    partial class FormModificar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            numeric_Edad = new NumericUpDown();
            gp_Gato = new GroupBox();
            label6 = new Label();
            txt_Raza = new TextBox();
            txt_Color = new TextBox();
            label7 = new Label();
            gp_Perro = new GroupBox();
            label5 = new Label();
            txt_Rol = new TextBox();
            txt_Tamanio = new TextBox();
            label4 = new Label();
            btn_Cancelar = new Button();
            btn_Modificar = new Button();
            grp_Vacunas = new GroupBox();
            checkBox6 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            label3 = new Label();
            label2 = new Label();
            cmb_Tipo = new ComboBox();
            label1 = new Label();
            txt_Nombre = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            ((System.ComponentModel.ISupportInitialize)numeric_Edad).BeginInit();
            gp_Gato.SuspendLayout();
            gp_Perro.SuspendLayout();
            grp_Vacunas.SuspendLayout();
            SuspendLayout();
            // 
            // numeric_Edad
            // 
            numeric_Edad.Location = new Point(117, 162);
            numeric_Edad.Name = "numeric_Edad";
            numeric_Edad.Size = new Size(206, 23);
            numeric_Edad.TabIndex = 23;
            // 
            // gp_Gato
            // 
            gp_Gato.Controls.Add(label6);
            gp_Gato.Controls.Add(txt_Raza);
            gp_Gato.Controls.Add(txt_Color);
            gp_Gato.Controls.Add(label7);
            gp_Gato.Location = new Point(507, 243);
            gp_Gato.Name = "gp_Gato";
            gp_Gato.Size = new Size(332, 124);
            gp_Gato.TabIndex = 24;
            gp_Gato.TabStop = false;
            gp_Gato.Text = "groupBox2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 25);
            label6.Name = "label6";
            label6.Size = new Size(34, 15);
            label6.TabIndex = 11;
            label6.Text = "Raza:";
            // 
            // txt_Raza
            // 
            txt_Raza.Location = new Point(120, 22);
            txt_Raza.Name = "txt_Raza";
            txt_Raza.Size = new Size(206, 23);
            txt_Raza.TabIndex = 9;
            // 
            // txt_Color
            // 
            txt_Color.Location = new Point(120, 78);
            txt_Color.Name = "txt_Color";
            txt_Color.Size = new Size(206, 23);
            txt_Color.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 81);
            label7.Name = "label7";
            label7.Size = new Size(81, 15);
            label7.TabIndex = 12;
            label7.Text = "Color de pelo:";
            // 
            // gp_Perro
            // 
            gp_Perro.Controls.Add(label5);
            gp_Perro.Controls.Add(txt_Rol);
            gp_Perro.Controls.Add(txt_Tamanio);
            gp_Perro.Controls.Add(label4);
            gp_Perro.Location = new Point(82, 243);
            gp_Perro.Name = "gp_Perro";
            gp_Perro.Size = new Size(332, 124);
            gp_Perro.TabIndex = 22;
            gp_Perro.TabStop = false;
            gp_Perro.Text = "groupBox1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 25);
            label5.Name = "label5";
            label5.Size = new Size(27, 15);
            label5.TabIndex = 11;
            label5.Text = "Rol:";
            // 
            // txt_Rol
            // 
            txt_Rol.Location = new Point(120, 22);
            txt_Rol.Name = "txt_Rol";
            txt_Rol.Size = new Size(206, 23);
            txt_Rol.TabIndex = 9;
            // 
            // txt_Tamanio
            // 
            txt_Tamanio.Location = new Point(120, 78);
            txt_Tamanio.Name = "txt_Tamanio";
            txt_Tamanio.Size = new Size(206, 23);
            txt_Tamanio.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 81);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 12;
            label4.Text = "Tamaño:";
            // 
            // btn_Cancelar
            // 
            btn_Cancelar.BackColor = Color.LemonChiffon;
            btn_Cancelar.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic);
            btn_Cancelar.Location = new Point(255, 392);
            btn_Cancelar.Margin = new Padding(3, 2, 3, 2);
            btn_Cancelar.Name = "btn_Cancelar";
            btn_Cancelar.Size = new Size(159, 39);
            btn_Cancelar.TabIndex = 21;
            btn_Cancelar.Text = "Cancelar";
            btn_Cancelar.UseVisualStyleBackColor = false;
            btn_Cancelar.Click += btn_cancelar_Click;
            // 
            // btn_Modificar
            // 
            btn_Modificar.BackColor = Color.LemonChiffon;
            btn_Modificar.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic);
            btn_Modificar.Location = new Point(507, 392);
            btn_Modificar.Margin = new Padding(3, 2, 3, 2);
            btn_Modificar.Name = "btn_Modificar";
            btn_Modificar.Size = new Size(159, 39);
            btn_Modificar.TabIndex = 20;
            btn_Modificar.Text = "Modificar";
            btn_Modificar.UseVisualStyleBackColor = false;
            btn_Modificar.Click += btn_modificar_Click;
            // 
            // grp_Vacunas
            // 
            grp_Vacunas.BackColor = SystemColors.InactiveCaption;
            grp_Vacunas.Controls.Add(checkBox6);
            grp_Vacunas.Controls.Add(checkBox5);
            grp_Vacunas.Controls.Add(checkBox4);
            grp_Vacunas.Controls.Add(checkBox3);
            grp_Vacunas.Controls.Add(checkBox2);
            grp_Vacunas.Controls.Add(checkBox1);
            grp_Vacunas.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grp_Vacunas.ForeColor = Color.Black;
            grp_Vacunas.Location = new Point(390, 31);
            grp_Vacunas.Margin = new Padding(3, 2, 3, 2);
            grp_Vacunas.Name = "grp_Vacunas";
            grp_Vacunas.Padding = new Padding(3, 2, 3, 2);
            grp_Vacunas.Size = new Size(468, 166);
            grp_Vacunas.TabIndex = 19;
            grp_Vacunas.TabStop = false;
            grp_Vacunas.Text = "Vacunas";
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.BackColor = Color.Transparent;
            checkBox6.Location = new Point(41, 114);
            checkBox6.Margin = new Padding(3, 2, 3, 2);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(160, 19);
            checkBox6.TabIndex = 5;
            checkBox6.Text = "Bordetella bronchiseptica";
            checkBox6.UseVisualStyleBackColor = false;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.BackColor = Color.Transparent;
            checkBox5.Location = new Point(247, 114);
            checkBox5.Margin = new Padding(3, 2, 3, 2);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(95, 19);
            checkBox5.TabIndex = 4;
            checkBox5.Text = "Leptospirosis";
            checkBox5.UseVisualStyleBackColor = false;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.BackColor = Color.Transparent;
            checkBox4.Location = new Point(41, 75);
            checkBox4.Margin = new Padding(3, 2, 3, 2);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(120, 19);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "Parvovirus canino";
            checkBox4.UseVisualStyleBackColor = false;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.BackColor = Color.Transparent;
            checkBox3.Location = new Point(247, 75);
            checkBox3.Margin = new Padding(3, 2, 3, 2);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(55, 19);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Rabia";
            checkBox3.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.Transparent;
            checkBox2.Location = new Point(41, 40);
            checkBox2.Margin = new Padding(3, 2, 3, 2);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(116, 19);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "Moquillo canino ";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Transparent;
            checkBox1.Location = new Point(247, 40);
            checkBox1.Margin = new Padding(3, 2, 3, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(167, 19);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Hepatitis infecciosa canina";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(-57, 164);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 18;
            label3.Text = "Edad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(-57, 99);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 17;
            label2.Text = "Nombre:";
            // 
            // cmb_Tipo
            // 
            cmb_Tipo.FormattingEnabled = true;
            cmb_Tipo.Location = new Point(117, 31);
            cmb_Tipo.Name = "cmb_Tipo";
            cmb_Tipo.Size = new Size(206, 23);
            cmb_Tipo.TabIndex = 16;
            cmb_Tipo.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(-57, 34);
            label1.Name = "label1";
            label1.Size = new Size(61, 15);
            label1.TabIndex = 15;
            label1.Text = "Elejir Tipo:";
            // 
            // txt_Nombre
            // 
            txt_Nombre.Location = new Point(117, 96);
            txt_Nombre.Name = "txt_Nombre";
            txt_Nombre.Size = new Size(206, 23);
            txt_Nombre.TabIndex = 14;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(28, 161);
            label8.Name = "label8";
            label8.Size = new Size(36, 15);
            label8.TabIndex = 27;
            label8.Text = "Edad:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(28, 96);
            label9.Name = "label9";
            label9.Size = new Size(54, 15);
            label9.TabIndex = 26;
            label9.Text = "Nombre:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(28, 31);
            label10.Name = "label10";
            label10.Size = new Size(61, 15);
            label10.TabIndex = 25;
            label10.Text = "Elejir Tipo:";
            // 
            // FormModificar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(926, 450);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(label10);
            Controls.Add(numeric_Edad);
            Controls.Add(gp_Gato);
            Controls.Add(gp_Perro);
            Controls.Add(btn_Cancelar);
            Controls.Add(btn_Modificar);
            Controls.Add(grp_Vacunas);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(cmb_Tipo);
            Controls.Add(label1);
            Controls.Add(txt_Nombre);
            Name = "FormModificar";
            Text = "FormModificar";
            Load += FormModificar_Load;
            ((System.ComponentModel.ISupportInitialize)numeric_Edad).EndInit();
            gp_Gato.ResumeLayout(false);
            gp_Gato.PerformLayout();
            gp_Perro.ResumeLayout(false);
            gp_Perro.PerformLayout();
            grp_Vacunas.ResumeLayout(false);
            grp_Vacunas.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private NumericUpDown numeric_Edad;
        private GroupBox gp_Gato;
        private Label label6;
        private TextBox txt_Raza;
        private TextBox txt_Color;
        private Label label7;
        private GroupBox gp_Perro;
        private Label label5;
        private TextBox txt_Rol;
        private TextBox txt_Tamanio;
        private Label label4;
        private Button btn_Cancelar;
        private Button btn_Modificar;
        private GroupBox grp_Vacunas;
        private CheckBox checkBox6;
        private CheckBox checkBox5;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private Label label3;
        private Label label2;
        private ComboBox cmb_Tipo;
        private Label label1;
        private TextBox txt_Nombre;
        private Label label8;
        private Label label9;
        private Label label10;
    }
}