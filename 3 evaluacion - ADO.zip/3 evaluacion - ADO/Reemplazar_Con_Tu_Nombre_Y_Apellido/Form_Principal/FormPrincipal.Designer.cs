﻿namespace Form_Principal
{
    partial class FormPrincipal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgb_Animales = new DataGridView();
            btn_Agregar = new Button();
            btn_Eliminar = new Button();
            btn_Modificar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgb_Animales).BeginInit();
            SuspendLayout();
            // 
            // dgb_Animales
            // 
            dgb_Animales.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgb_Animales.Location = new Point(0, 0);
            dgb_Animales.Name = "dgb_Animales";
            dgb_Animales.Size = new Size(800, 297);
            dgb_Animales.TabIndex = 0;
            // 
            // btn_Agregar
            // 
            btn_Agregar.Location = new Point(324, 340);
            btn_Agregar.Name = "btn_Agregar";
            btn_Agregar.Size = new Size(112, 35);
            btn_Agregar.TabIndex = 1;
            btn_Agregar.Text = "Agregar";
            btn_Agregar.UseVisualStyleBackColor = true;
            btn_Agregar.Click += btn_Agregar_Click;
            // 
            // btn_Eliminar
            // 
            btn_Eliminar.Location = new Point(143, 340);
            btn_Eliminar.Name = "btn_Eliminar";
            btn_Eliminar.Size = new Size(113, 35);
            btn_Eliminar.TabIndex = 2;
            btn_Eliminar.Text = "Eliminar";
            btn_Eliminar.UseVisualStyleBackColor = true;
            btn_Eliminar.Click += btn_Eliminar_Click;
            // 
            // btn_Modificar
            // 
            btn_Modificar.Location = new Point(508, 340);
            btn_Modificar.Name = "btn_Modificar";
            btn_Modificar.Size = new Size(119, 35);
            btn_Modificar.TabIndex = 3;
            btn_Modificar.Text = "Modificar";
            btn_Modificar.UseVisualStyleBackColor = true;
            btn_Modificar.Click += btn_Modificar_Click;
            // 
            // FormPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_Modificar);
            Controls.Add(btn_Agregar);
            Controls.Add(btn_Eliminar);
            Controls.Add(dgb_Animales);
            Name = "FormPrincipal";
            Text = "Form1";
            Load += Form_Principal_Load;
            ((System.ComponentModel.ISupportInitialize)dgb_Animales).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgb_Animales;
        private Button btn_Agregar;
        private Button btn_Eliminar;
        private Button btn_Modificar;
    }
}
