﻿namespace Form_Animales
{
    partial class FormAlta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAlta));
            txt_Nombre = new TextBox();
            label1 = new Label();
            cmb_Tipo = new ComboBox();
            label2 = new Label();
            label3 = new Label();
            grp_Vacunas = new GroupBox();
            checkBox6 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            btn_Crear = new Button();
            btn_Cancelar = new Button();
            label4 = new Label();
            label5 = new Label();
            txt_Tamanio = new TextBox();
            txt_Rol = new TextBox();
            gp_Perro = new GroupBox();
            gp_Gato = new GroupBox();
            label6 = new Label();
            txt_Raza = new TextBox();
            txt_Color = new TextBox();
            label7 = new Label();
            numeric_Edad = new NumericUpDown();
            pictureBox1 = new PictureBox();
            grp_Vacunas.SuspendLayout();
            gp_Perro.SuspendLayout();
            gp_Gato.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numeric_Edad).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txt_Nombre
            // 
            txt_Nombre.Location = new Point(152, 88);
            txt_Nombre.Name = "txt_Nombre";
            txt_Nombre.Size = new Size(206, 23);
            txt_Nombre.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label1.Location = new Point(38, 26);
            label1.Name = "label1";
            label1.Size = new Size(91, 21);
            label1.TabIndex = 1;
            label1.Text = "Elejir Tipo:";
            // 
            // cmb_Tipo
            // 
            cmb_Tipo.FormattingEnabled = true;
            cmb_Tipo.Location = new Point(152, 23);
            cmb_Tipo.Name = "cmb_Tipo";
            cmb_Tipo.Size = new Size(206, 23);
            cmb_Tipo.TabIndex = 2;
            cmb_Tipo.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label2.Location = new Point(38, 91);
            label2.Name = "label2";
            label2.Size = new Size(77, 21);
            label2.TabIndex = 4;
            label2.Text = "Nombre:";
            // 
            // label3
            // 
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            label3.Location = new Point(38, 156);
            label3.Name = "label3";
            label3.Size = new Size(77, 21);
            label3.TabIndex = 5;
            label3.Text = "Edad:";
            // 
            // grp_Vacunas
            // 
            grp_Vacunas.BackColor = SystemColors.InactiveCaption;
            grp_Vacunas.Controls.Add(checkBox6);
            grp_Vacunas.Controls.Add(checkBox5);
            grp_Vacunas.Controls.Add(checkBox4);
            grp_Vacunas.Controls.Add(checkBox3);
            grp_Vacunas.Controls.Add(checkBox2);
            grp_Vacunas.Controls.Add(checkBox1);
            grp_Vacunas.Controls.Add(pictureBox1);
            grp_Vacunas.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            grp_Vacunas.ForeColor = Color.Black;
            grp_Vacunas.Location = new Point(485, 23);
            grp_Vacunas.Margin = new Padding(3, 2, 3, 2);
            grp_Vacunas.Name = "grp_Vacunas";
            grp_Vacunas.Padding = new Padding(3, 2, 3, 2);
            grp_Vacunas.Size = new Size(468, 166);
            grp_Vacunas.TabIndex = 6;
            grp_Vacunas.TabStop = false;
            grp_Vacunas.Text = "Vacunas";
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.BackColor = Color.Transparent;
            checkBox6.Location = new Point(41, 115);
            checkBox6.Margin = new Padding(3, 2, 3, 2);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(160, 19);
            checkBox6.TabIndex = 5;
            checkBox6.Text = "Bordetella bronchiseptica";
            checkBox6.UseVisualStyleBackColor = false;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.BackColor = Color.Transparent;
            checkBox5.Location = new Point(247, 115);
            checkBox5.Margin = new Padding(3, 2, 3, 2);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(95, 19);
            checkBox5.TabIndex = 4;
            checkBox5.Text = "Leptospirosis";
            checkBox5.UseVisualStyleBackColor = false;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.BackColor = Color.Transparent;
            checkBox4.Location = new Point(41, 76);
            checkBox4.Margin = new Padding(3, 2, 3, 2);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(120, 19);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "Parvovirus canino";
            checkBox4.UseVisualStyleBackColor = false;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.BackColor = Color.Transparent;
            checkBox3.Location = new Point(247, 76);
            checkBox3.Margin = new Padding(3, 2, 3, 2);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(55, 19);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Rabia";
            checkBox3.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.BackColor = Color.Transparent;
            checkBox2.Location = new Point(41, 41);
            checkBox2.Margin = new Padding(3, 2, 3, 2);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(116, 19);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "Moquillo canino ";
            checkBox2.UseVisualStyleBackColor = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Transparent;
            checkBox1.Location = new Point(247, 41);
            checkBox1.Margin = new Padding(3, 2, 3, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(167, 19);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Hepatitis infecciosa canina";
            checkBox1.UseVisualStyleBackColor = false;
            // 
            // btn_Crear
            // 
            btn_Crear.BackColor = Color.LemonChiffon;
            btn_Crear.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic);
            btn_Crear.Location = new Point(519, 390);
            btn_Crear.Margin = new Padding(3, 2, 3, 2);
            btn_Crear.Name = "btn_Crear";
            btn_Crear.Size = new Size(159, 39);
            btn_Crear.TabIndex = 7;
            btn_Crear.Text = "Crear";
            btn_Crear.UseVisualStyleBackColor = false;
            btn_Crear.Click += btn_Crear_Click;
            // 
            // btn_Cancelar
            // 
            btn_Cancelar.BackColor = Color.LemonChiffon;
            btn_Cancelar.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic);
            btn_Cancelar.Location = new Point(267, 390);
            btn_Cancelar.Margin = new Padding(3, 2, 3, 2);
            btn_Cancelar.Name = "btn_Cancelar";
            btn_Cancelar.Size = new Size(159, 39);
            btn_Cancelar.TabIndex = 8;
            btn_Cancelar.Text = "Cancelar";
            btn_Cancelar.UseVisualStyleBackColor = false;
            btn_Cancelar.Click += btn_Cancelar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 81);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 12;
            label4.Text = "Tamaño:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 25);
            label5.Name = "label5";
            label5.Size = new Size(27, 15);
            label5.TabIndex = 11;
            label5.Text = "Rol:";
            // 
            // txt_Tamanio
            // 
            txt_Tamanio.Location = new Point(120, 78);
            txt_Tamanio.Name = "txt_Tamanio";
            txt_Tamanio.Size = new Size(206, 23);
            txt_Tamanio.TabIndex = 10;
            // 
            // txt_Rol
            // 
            txt_Rol.Location = new Point(120, 22);
            txt_Rol.Name = "txt_Rol";
            txt_Rol.Size = new Size(206, 23);
            txt_Rol.TabIndex = 9;
            // 
            // gp_Perro
            // 
            gp_Perro.BackColor = Color.Transparent;
            gp_Perro.Controls.Add(label5);
            gp_Perro.Controls.Add(txt_Rol);
            gp_Perro.Controls.Add(txt_Tamanio);
            gp_Perro.Controls.Add(label4);
            gp_Perro.Location = new Point(94, 223);
            gp_Perro.Name = "gp_Perro";
            gp_Perro.Size = new Size(332, 124);
            gp_Perro.TabIndex = 10;
            gp_Perro.TabStop = false;
            gp_Perro.Text = "groupBox1";
            // 
            // gp_Gato
            // 
            gp_Gato.BackColor = Color.Transparent;
            gp_Gato.Controls.Add(label6);
            gp_Gato.Controls.Add(txt_Raza);
            gp_Gato.Controls.Add(txt_Color);
            gp_Gato.Controls.Add(label7);
            gp_Gato.Location = new Point(519, 223);
            gp_Gato.Name = "gp_Gato";
            gp_Gato.Size = new Size(332, 124);
            gp_Gato.TabIndex = 13;
            gp_Gato.TabStop = false;
            gp_Gato.Text = "groupBox2";
            // 
            // label6
            // 
            label6.BackColor = Color.LightSteelBlue;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(0, 25);
            label6.Name = "label6";
            label6.Size = new Size(116, 21);
            label6.TabIndex = 11;
            label6.Text = "Raza:";
            // 
            // txt_Raza
            // 
            txt_Raza.Location = new Point(120, 22);
            txt_Raza.Name = "txt_Raza";
            txt_Raza.Size = new Size(206, 23);
            txt_Raza.TabIndex = 9;
            // 
            // txt_Color
            // 
            txt_Color.Location = new Point(120, 78);
            txt_Color.Name = "txt_Color";
            txt_Color.Size = new Size(206, 23);
            txt_Color.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.LightSteelBlue;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(0, 80);
            label7.Name = "label7";
            label7.Size = new Size(116, 21);
            label7.TabIndex = 12;
            label7.Text = "Color de pelo:";
            // 
            // numeric_Edad
            // 
            numeric_Edad.Location = new Point(152, 154);
            numeric_Edad.Name = "numeric_Edad";
            numeric_Edad.Size = new Size(206, 23);
            numeric_Edad.TabIndex = 13;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Location = new Point(-486, -25);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(1004, 451);
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // FormAlta
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1005, 465);
            Controls.Add(numeric_Edad);
            Controls.Add(gp_Gato);
            Controls.Add(gp_Perro);
            Controls.Add(btn_Cancelar);
            Controls.Add(btn_Crear);
            Controls.Add(grp_Vacunas);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(cmb_Tipo);
            Controls.Add(label1);
            Controls.Add(txt_Nombre);
            Name = "FormAlta";
            Text = "Form_Alta";
            Load += FormAlta_Load;
            grp_Vacunas.ResumeLayout(false);
            grp_Vacunas.PerformLayout();
            gp_Perro.ResumeLayout(false);
            gp_Perro.PerformLayout();
            gp_Gato.ResumeLayout(false);
            gp_Gato.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numeric_Edad).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_Nombre;
        private Label label1;
        private ComboBox cmb_Tipo;
        private Label label2;
        private Label label3;
        private GroupBox grp_Vacunas;
        private CheckBox checkBox6;
        private CheckBox checkBox5;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Button btn_Crear;
        private Button btn_Cancelar;
        private Label label4;
        private Label label5;
        private TextBox txt_Tamanio;
        private TextBox txt_Rol;
        private GroupBox gp_Perro;
        private GroupBox gp_Gato;
        private Label label6;
        private TextBox txt_Raza;
        private TextBox txt_Color;
        private Label label7;
        private NumericUpDown numeric_Edad;
        private PictureBox pictureBox1;
    }
}